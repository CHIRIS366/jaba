global.Promise = require("promise");
